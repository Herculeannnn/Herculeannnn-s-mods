MPC ARCHIVE — SETUP GUIDE
========================

WHAT THIS IS
- Public Minecraft Bedrock pack catalogue.
- Visitors can browse and download .mcpack files.
- Only the configured admin email can sign in and upload.
- GitHub Pages hosts the website; Supabase stores pack details and files.

PART 1 — UPLOAD WEBSITE FILES TO GITHUB
1. Open your mpc-archive repository.
2. Tap Add file > Upload files.
3. Upload: index.html, styles.css, config.js, app.js.
4. Commit the files to the main branch.
5. Do NOT upload private keys or passwords.

PART 2 — CREATE SUPABASE PROJECT
1. Open https://supabase.com/ and create a free project.
2. Save the database password somewhere safe; it is not used in this website.
3. Open SQL Editor > New query.
4. Open supabase-schema.sql from this folder.
5. Replace BOTH occurrences of YOUR_ADMIN_EMAIL in that SQL file with your own email.
6. Run the SQL.
7. Open Project Settings > API (or Data API / API Keys, depending on dashboard layout).
8. Copy the Project URL and anon/public key. NEVER use the service_role or secret key.

PART 3 — CONFIGURE THE WEBSITE
1. Open config.js in your GitHub repository and tap Edit.
2. Replace PASTE_SUPABASE_PROJECT_URL_HERE with your Supabase Project URL.
3. Replace PASTE_SUPABASE_ANON_PUBLIC_KEY_HERE with the anon/public key.
4. Replace PASTE_YOUR_ADMIN_EMAIL_HERE with the same admin email used in the SQL.
5. Commit changes.

PART 4 — ENABLE GITHUB PAGES
1. In the GitHub repository, open Settings.
2. Open Pages.
3. Under Build and deployment, choose Deploy from a branch.
4. Choose branch main and folder /(root), then Save.
5. Wait for GitHub Pages to publish the site.

PART 5 — SUPABASE AUTH REDIRECT
1. In Supabase, open Authentication > URL Configuration.
2. Set Site URL to your GitHub Pages website address.
3. Add that same address under Redirect URLs.
4. In Authentication providers, ensure Email is enabled.

PART 6 — USE IT
1. Open the published website.
2. Tap Admin login.
3. Enter the configured admin email and open the sign-in link sent to that email.
4. Tap Upload pack and fill in the form.
5. Visitors can download packs from the public catalogue.

IMPORTANT SECURITY
- The anon/public key is designed to be used in a browser; database/storage policies protect admin actions.
- NEVER put a Supabase service_role key, secret key, database password, or GitHub personal access token in config.js or any website file.
- Anyone can download files in the public pack-files bucket.
- The initial version publishes new versions as separate entries. Editing/deleting pack entries can be added in a later admin update.
- The initial upload limit is 100 MB per pack. Free-tier limits may change; check your Supabase dashboard.
- Do not upload packs you do not have permission to redistribute.

If something fails, send a screenshot of the exact page/error. Do not post secret keys or passwords.
